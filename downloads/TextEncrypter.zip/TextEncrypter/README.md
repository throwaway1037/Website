# TextEncrypter
Encrypts text before being sent.

This program allows Bob to enter Alice as a contact.
Then add symetric encryption keys to this contact (as many as he likes).

Alice does the same and adds the same encryption keys.

Now Bob can send a message to Alice by

    1. Selecting her contact
    2. Selecting Encrypt
    3. Enters: "Hello"
    4. Cipher text is automatically copied to Bobs clipboard.
    5. Bob pastes this message into any messanger.

Aims of this program

Offers greater protection against quantum computers than asymetric encryption, therefore hopefully adds some future security.

Can offer higher security by offering as many layers of encryption as the user wants.

Provides an extra layer of security such as if an account is hacked, then if this program used, messages should not be visable.

Allows secure communication over insecure platform or network.

